using MovieService.Interfaces;  // Correct namespace for IMovieService
using MovieService.Services;   // Correct namespace for MovieService (class)
using MovieService.Models;     // Correct namespace for your Movie model
using System;
using System.Text;

var builder = WebApplication.CreateBuilder(args);

// Generate a new API Key using GUID for this session (for demonstration purposes)
string apiKey = Guid.NewGuid().ToString("N"); // Generate API key without hyphens
Console.WriteLine("Generated API Key: " + apiKey); // Log the API key (use for initial testing)

// Add services to the container
builder.Services.AddControllers();  // Register the controller services

// Register the MovieService with the IMovieService interface
builder.Services.AddScoped<IMovieService, MovieService.Services.MovieService>();  // Fully qualify MovieService to avoid namespace conflict

// Register the API key to be used throughout the app
builder.Services.AddSingleton(apiKey);  // This makes the apiKey available app-wide

builder.Services.AddEndpointsApiExplorer();  // Add support for endpoint explorer
builder.Services.AddSwaggerGen();  // Add Swagger generation

var app = builder.Build();  // Build the application

// Configure the HTTP request pipeline
if (app.Environment.IsDevelopment())  // Enable Swagger only in development mode
{
    app.UseSwagger();  // Enable Swagger UI
    app.UseSwaggerUI();  // Enable Swagger UI for interactive API documentation
}

app.UseHttpsRedirection();  // Redirect HTTP to HTTPS

// Basic Authentication Middleware
app.Use(async (context, next) =>
{
    // Check if the Authorization header exists
    var authHeader = context.Request.Headers["Authorization"].ToString();

    if (string.IsNullOrWhiteSpace(authHeader) || !authHeader.StartsWith("Basic "))
    {
        // If no valid Authorization header is provided, send a 401 response
        context.Response.StatusCode = 401;
        context.Response.Headers["WWW-Authenticate"] = "Basic realm=\"MovieService\"";
        await context.Response.WriteAsync("Authentication required.");
        return;
    }

    // Decode the Base64-encoded credentials
    var encodedCredentials = authHeader.Substring("Basic ".Length).Trim();
    var credentialBytes = Convert.FromBase64String(encodedCredentials);
    var credentials = Encoding.UTF8.GetString(credentialBytes).Split(':');

    if (credentials.Length == 2)
    {
        var username = credentials[0];
        var password = credentials[1];

        // Validate the username and password
        if (username == "admin" && password == "password123")
        {
            // If valid, proceed to the next middleware
            await next();
            return;
        }
    }

    // If authentication fails, send a 401 response
    context.Response.StatusCode = 401;
    context.Response.Headers["WWW-Authenticate"] = "Basic realm=\"MovieService\"";
    await context.Response.WriteAsync("Invalid credentials.");
    return;
});

app.UseAuthorization();  // Use authorization middleware (if applicable)

app.MapControllers();  // Map controllers for handling incoming HTTP requests

app.Run();  // Run the application

