﻿using MovieService.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace MovieService.Interfaces
{
    public interface IMovieService
    {
        Task<List<Movie>> GetMoviesAsync(string title, string apiKey);
        Task<Movie> GetMovieDetailsAsync(string id, string apiKey);
    }
}
