﻿using MovieService.Interfaces;
using MovieService.Models;
using Newtonsoft.Json;
using System.Collections.Generic;
using System.Net.Http;
using System.Threading.Tasks;

namespace MovieService.Services
{
    public class MovieService : IMovieService
    {
        private readonly HttpClient _httpClient;

        // Constructor to inject HttpClient
        public MovieService(HttpClient httpClient)
        {
            _httpClient = httpClient;
        }

        // Method to search movies from OMDb API based on a title (query)
        public async Task<List<Movie>> GetMoviesAsync(string title, string apiKey)
        {
            var url = $"http://www.omdbapi.com/?s={title}&apikey={apiKey}";  // API endpoint to search for movies
            var response = await _httpClient.GetStringAsync(url);  // Send the request to OMDb API
            var movies = JsonConvert.DeserializeObject<MovieSearchResult>(response);  // Deserialize the response into a MovieSearchResult object
            return movies?.Search ?? new List<Movie>();  // Return the list of movies or an empty list if no results
        }

        // Method to get detailed information about a specific movie from OMDb API using its ID
        public async Task<Movie> GetMovieDetailsAsync(string id, string apiKey)
        {
            var url = $"http://www.omdbapi.com/?i={id}&apikey={apiKey}";  // API endpoint to get movie details by ID
            var response = await _httpClient.GetStringAsync(url);  // Send the request to OMDb API
            return JsonConvert.DeserializeObject<Movie>(response);  // Deserialize the response into a Movie object
        }
    }
}
