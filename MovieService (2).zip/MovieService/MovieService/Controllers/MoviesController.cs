﻿using Microsoft.AspNetCore.Mvc;
using MovieService.Interfaces;
using MovieService.Models;
using Microsoft.Extensions.Configuration; // To access configuration
using System.Threading.Tasks;

namespace MovieService.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class MoviesController : ControllerBase
    {
        private readonly IMovieService _movieService;
        private readonly string _apiKey;  // Store the API key

        // Constructor to inject the MovieService and API key from the configuration
        public MoviesController(IMovieService movieService, IConfiguration configuration)
        {
            _movieService = movieService;
            _apiKey = configuration.GetValue<string>("ApiKey");  // Get API key from configuration
        }

        // GET api/movies?s=[movie title]
        [HttpGet]
        public async Task<ActionResult> GetMovies([FromQuery] string s)
        {
            if (string.IsNullOrEmpty(s))
            {
                return BadRequest("The 's' (movie title) parameter is required.");
            }

            // Fetch movies from the service using the API key
            var movies = await _movieService.GetMoviesAsync(s, _apiKey);

            if (movies == null || movies.Count == 0)
            {
                return NotFound("No movies found for the given title.");
            }

            return Ok(movies);
        }

        // GET api/movies/details?id=[movie id]
        [HttpGet("details")]
        public async Task<ActionResult> GetMovieDetails([FromQuery] string id)
        {
            if (string.IsNullOrEmpty(id))
            {
                return BadRequest("The 'id' (movie ID) parameter is required.");
            }

            // Fetch movie details using the ID
            var movieDetails = await _movieService.GetMovieDetailsAsync(id, _apiKey);

            if (movieDetails == null)
            {
                return NotFound("Movie details not found.");
            }

            return Ok(movieDetails);
        }
    }
}
